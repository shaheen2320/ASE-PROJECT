﻿namespace Draw_tests
{
    internal class Picture_Box
    {
    }
}